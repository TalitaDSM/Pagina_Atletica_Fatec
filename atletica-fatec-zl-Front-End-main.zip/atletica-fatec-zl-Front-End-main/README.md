# atletica-fatec-ZL
Projeto interdisciplinar do 2º Semestre do Curso de Desenvolvimento de Software Multiplataforma da Fatec Zona Leste - Tema: Sistema web da Atlética da Fatec ZL

This repository holds a web based software developed in the 2º semester of Software Developer graduation course at FATEC. Theme: Athletic Commission

Link: https://alanserafim.github.io/atletica-fatec-zl/

<br>

## Screenshots (03-03-2022) 

### Desktop 

<img src="assets\img\screenshots\Alanserafim - Full - Generic Laptop - 2022-03-03 at 6.10.50 PM.jpg" alt="Desktop" style="width:700px;">

<br>

### Tablet 

<img src="assets\img\screenshots\Alanserafim - Full - iPad - 2022-03-03 at 6.10.43 PM.jpg" alt="Tablet" style="width:500px;">

<br>

### Mobile 

<img src="assets\img\screenshots\Alanserafim - Full - iPhone 6-7-8 - 2022-03-03 at 6.10.36 PM.jpg" alt="Mobile" style="width:350px;">

